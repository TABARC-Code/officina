# Changelog — Officina

## 1.8.2 — Description over character limit

The `description` field parsed to 1027 characters, 3 over the Agent Skills spec's 1024 limit. Trimmed to 986 with real margin rather than the bare minimum: dropped one redundant trigger phrase ("I fixed what you flagged" was covering the same ground as "here's the revised version," both already signal the Return Pass) and tightened "one gestalt lab-partner voice" to "one merged voice." Re-verified the trimmed length by actually parsing the YAML and measuring the resulting string, not by eyeballing the source text, since raw source length and parsed string length aren't the same thing once escaped characters are involved.

Checked `production-baseline-control`'s description too (782 characters, safe) and both skills' `name` fields against the 64-character name limit (8 and 27 characters, both fine).

Worth flagging honestly: some documentation suggests Claude.ai's own Custom Skills upload UI may enforce a stricter 200-character description limit, separate from the 1024-character Agent Skills spec limit this fix addresses. That hasn't come up as an actual error yet, so it wasn't corrected for pre-emptively, but if a second, different length complaint shows up after this fix, that's almost certainly what it is.

## 1.8.1 — Malformed YAML fix

The frontmatter was genuinely broken. The `description` field is wrapped in single quotes, and a single-quoted YAML string needs a literal apostrophe doubled (`''`) or the string closes early. The v1.7.0 trigger phrase "here's the revised version" introduced an unescaped apostrophe that did exactly that, and it sat there through three subsequent version bumps because every check run against this file up to now was a text grep, never an actual YAML parse. Grep cannot catch a parser-level syntax error. This is exactly the kind of thing the professional QA pass should have caught and didn't, because it wasn't looking with the right tool.

Fixed by escaping the apostrophe. Re-validated with a real YAML parser this time, not a text pattern, and checked the rest of the description field for other unescaped apostrophes (none found) and checked `production-baseline-control`'s `SKILL.md` and `CORE.md` frontmatter too, since both carry the same single-quote structure and neither had been parser-checked either. Both came back valid.

Going forward, any edit that touches a frontmatter field gets parsed with `yaml.safe_load`, not just grepped, before it's called finished.

## 1.8.0 — Newbie-ready packaging

Rewrote README.md from scratch in a genuine first-person voice (UK English, deliberately uneven paragraph length, no em dashes) and added description.md as a separate file carrying the GitHub repo description line plus a longer pitch. Added a full step by step setup guide aimed at someone who has never touched a Claude skill before, sourced from the official Claude Help Center article on using skills rather than guessed at, since giving a newbie wrong install steps would be actively worse than giving none.

Wrote this pass without a single em dash, on purpose. Every prior instance of the escape sequence bug that kept resurfacing this session happened specifically on em dash or en dash characters, so avoiding them here satisfies the user's stated style preference and removes the bug's actual trigger at the same time, rather than just catching it after the fact again.

## 1.7.2 — Install-ready packaging

Added `README.md` — GitHub-facing documentation distinct from `SKILL.md` (which is the runtime entry point, not a human-facing intro). Includes a GitHub repo description line, a plain-English "idiot's guide" section, and repo structure/quick-start sections, in UK English throughout. Checked against the recurring escape-sequence bug and against American spellings before packaging — both clean.

## 1.7.1 — Sidecar link to production-baseline-control

Adopted a second uploaded skill, `production-baseline-control`, as its own standalone sibling skill rather than folding it into Officina (most of it doesn't fit here — see that skill's own CHANGELOG.md for the intake details). Added the reciprocal half of the relationship contract on Officina's side: a new sidecar entry in `RELATIONSHIP_MAP.md`, and a boundary statement in SKILL.md § Relationship to Other TABARC Skills stating when to mention the sibling skill (full council session ends in Keep, user signals they're about to actually build or ship). Unlike the perdita-mode entry, this contract is verified on both sides in the same pass, since both skills were touched in the same session.

## 1.7.0 — The Return Pass

**Added: The Return Pass.** Sourced from an uploaded `production-baseline-control` skill — a domain-neutral system for tracking deployed products, documents, and manufactured objects across releases, with 15 phases, JSON schemas, a decision ledger, release gates, monitoring cadences, and severity-classified incident response. Nearly all of it stayed out: Officina doesn't deploy, release, or continuously monitor anything, so that machinery has no object to operate on here. What genuinely transferred was one discipline — don't re-litigate a returned idea from zero, and don't conflate "still broken," "newly broken," and "never actually tested" when someone comes back with a revision.

Implemented as a conditional pre-loop stage (not a numbered Triage Loop step, since it only runs on return visits): the prior verdict becomes a baseline, the new drop becomes a candidate, and the comparison sorts into four buckets — Resolved, Unresolved, Regression, Drifted — rather than a blanket "looks better now." Carries its own anti-pattern: effort isn't evidence, the specific objection gets checked against the specific change.

**Consistency updates:** frontmatter description gained Return Pass trigger phrases ("here's the revised version," "I fixed what you flagged"). `RELATIONSHIP_MAP.md`'s SKILL.md ↔ protocol.md contract updated to name all three protocol.md stages (Trickster, Return Pass, triage loop) rather than going stale the way it did after 1.5.0. One new eval (#5) added — a bike-lock revision that partially fixes the original objection but introduces two new ones (sleeve as new attack surface, added cost/weight), testing that the Return Pass doesn't just credit visible effort.

**Verified after edit:** JSON valid, protocol.md's Triage Loop intro correctly references the new conditional stage without renumbering the existing 0–7 steps, RELATIONSHIP_MAP.md's stated audit standard ("nothing here unreflected in the actual files") re-satisfied for the contract that went stale last time.

## 1.6.0 — Structural re-check

A full re-read of the package looking for drift and unhandled cases, not incremental patching. Six real findings, all fixed:

1. **Summary/detail drift (SKILL.md):** Da Vinci's condensed "leads on" cue dropped the broadest clause from its personas.md source ("anything that needs a structural analogy borrowed from an unrelated field"), leaving it reading as physical-object-only. Since five of six lenses trace to physical inventors, this risked silently excluding abstract/process ideas from the one lens actually suited to them. Restored.
2. **Unhandled case (protocol.md § The Trickster):** no stated behaviour for when the Trickster's reframed objective *also* fails the critique. Previously this could silently fall back to the original objective, hiding that a reframe was tried and burying why it failed. Now: report both objectives and why the reframe specifically failed; end in a Discard on the reframe, not a quiet reversion.
3. **No null-result behaviour (protocol.md § The Spider-Swarm):** nothing said what to do when a search comes back empty or the tool fails. Added: state the gap plainly, don't reason with search-level confidence off an empty search.
4. **Undefined mode relationship (SKILL.md § Working Modes):** whether Transcript mode runs the full loop (Trickster, swarm, permutations, verification) or is a lighter variant was never stated, even though eval #4 already assumed the former. Clarified explicitly: transcript mode is a presentation choice, not a lighter mode — same loop, dialogue instead of prose at Converge.
5. **Stale relationship contract (RELATIONSHIP_MAP.md):** the SKILL.md ↔ protocol.md contract still described protocol.md as covering only "the triage loop," unchanged since before the Trickster was added in 1.5.0 — violating the file's own stated standard that nothing here should be unreflected in the actual files. Updated.
6. **Evals drifted from actual expected behaviour (evals.json):** eval #2 and #4 were both written before the Trickster pass existed and would currently pass even if it silently never ran. Updated both to require the Trickster verdict stated as its own line; eval #4 additionally updated to reflect the transcript-mode clarification (#4 above) and to test a case where the Trickster's likely reframe and the Fuller/Franklin critique reinforce rather than contradict each other.

**Considered and rejected:**
- Merging `personas.md` and `protocol.md` into one file to cut a tool-call round trip on full council sessions. Rejected — breaks the data/consumer separation the existing relationship contract depends on, for a marginal efficiency gain.
- A "medium" working mode between Quick reaction and Full council. Rejected — Single-lens consult already fills most of that gap, and a fifth mode risks over-formalising sessions that don't need it.

## 1.5.0 — The Trickster + verification pass

**Added: The Trickster.** All six lenses inherit the user's stated objective as given and refine within it — none of them check whether the objective itself is the right one. Sourced from an uploaded article describing a premise-challenging AI module (an "Optimiser vs. Trickster" framing from a separate Adversarial Cognition Framework piece) and adapted rather than copied — no verbatim text carried over, own examples and wording throughout. Implemented as a new premise-check stage (Triage Loop step 0), not a seventh persona: it operates one level up from the six lenses (game vs. move) and doesn't fit the three-pair symmetric structure without forcing it, so it stays a separate stage rather than breaking that structure. The article's "Referee" role needed no new persona either — Officina's gestalt core already plays that convening role at Converge, so it was named as such rather than invented twice. Full-council-session default, skipped in quick reaction mode to avoid turning every fast drop-in into a premise audit. Carries its own anti-pattern guard against becoming reflexive contrarianism, mirroring the source material's own caution that not every session should end in a paradigm shift.

**Added: Verification pass (Triage Loop step 7).** Sourced from a separate multi-agent coding-orchestrator prompt the user shared — most of it didn't transfer (executor routing to named external models has no analogue in Officina's single-gestalt-core architecture, file:line/worktree language is code-review specific), but one discipline was a genuine gap: re-reading the finished output against what was actually found and reasoned, before presenting it, rather than trusting the first draft of Converge to be correct. Checks specifically for a verdict that doesn't match its own stated reason, and for final wording that contradicts something the swarm found earlier without explanation. Internal only — doesn't add a step to the user-facing Shape of a Converged Output, since nothing changes in what's shown unless the check catches something.

**Updated for consistency:** frontmatter description gained a Trickster-specific trigger phrase ("am I solving the right problem") for reachability. Working Modes table's full-council row now states the Trickster pass as the first stage. Reference-file header backlinks in `protocol.md` updated to point at the new sections.

## 1.4.1 — Professional QA pass

Full read-through of every file, line by line, rather than a targeted grep for known bug shapes — this is what caught what the previous automated passes missed.

**Fixed:**
- `SKILL.md` line 27 — self-contradicted within one sentence: "built from six thinking styles, not five people doing impressions." Every prior "five/six" grep searched for exact phrases like "five-voice" and missed this because it's lowercase and worded differently. Corrected to "not six people."
- `SKILL.md` Anti-Patterns — "No five polite paragraphs that all agree" was ambiguous against a six-lens roster; changed to six for consistency.
- `SKILL.md` Working Modes table — "User names a specific figure" changed to "specific lens," matching the terminology used everywhere else in the document.
- `references/personas.md` — Vagadesamaso's entry was the only one of six using a gendered pronoun ("he refuses"). The other five entries are pronoun-free by convention, and the Naming Note explicitly states this lens isn't a claim about a specific individual — the pronoun undercut its own stated intent. Rewritten to match the pronoun-free style of the other five.
- `references/personas.md` — field-label capitalisation was split two ways: "Paired Check" and "Signature Move" in Title Case, "Habitual question," "Voice notes," "Unchecked failure mode," and "When this lens leads" in sentence case. Standardised all seven fields to Title Case across all six entries (verified: 6 occurrences each, no leftovers).
- `CHANGELOG.md` — the v1.4.0 entry contained literal `\u2194` and `\u2014` text instead of actual ↔ and — characters, a leftover from writing escaped text into a markdown file instead of the real symbol. Swept the whole package for the same pattern; it was isolated to this one file.

**Verified after edit:** JSON still valid, no orphaned "Savage" outside the intentional naming-note quote and historical changelog entries, five/six references all correct on a full-package grep, all seven persona field labels consistent at 6/6/6/6/6/6/6.

## 1.4.0 — Coverage pass

Re-audited the actual package rather than repeating the previous pass. Found and closed:

- **Reachability gap (SKILL.md frontmatter):** description covered quick-reaction and full-council triggers but had no trigger phrase for transcript mode. Added "have them argue it out."
- **Eval coverage gap (evals/evals.json):** three existing evals covered quick reaction, full council, and single-lens consult, but nothing covered transcript mode, nothing isolated the Fuller ↔ Franklin pair on its own, and every existing verdict landed on Keep or Refine — none tested an outright Discard. Added eval #4: transcript mode, Fuller/Franklin pair, converging to a Discard. One eval closing three gaps rather than three separate additions.

**Considered and dropped:** a fifth eval for quick reaction mode with a smoke-detector prompt. On review it didn't test anything eval #1 doesn't already cover — added, then removed, rather than left in as padding. Recorded here so the decision not to add it is visible, not just the decision to add what's kept.

## 1.3.0 — Rename + improvements pass

**Renamed:** "Adam Savage" → "Vagadesamaso" across every live file (`SKILL.md`, `references/personas.md`, `references/protocol.md`, `RELATIONSHIP_MAP.md`, `evals/evals.json`). Brings the sixth lens in line with the single-token naming already used for Newton, Tesla, Fuller, and Franklin, and moves the lens away from naming a real, living public figure directly. Historical entries below this one that predate the rename were left as-is — they describe what was true at the time, not what's current.

**Added:**
- Naming note in `SKILL.md` explaining what Vagadesamaso is and why the rename happened, so the name isn't an unexplained artifact for a future audit to puzzle over.
- "→ leads on:" cue on each of the six lens summaries in `SKILL.md`, condensed from personas.md's "When This Lens Leads" field — lets quick reaction mode pick a lens fast without a full personas.md read. Flagged as a tracked duplication in `RELATIONSHIP_MAP.md` (the one deliberate content overlap in the package) rather than left as a silent drift risk.
- Structured Capture step in `references/protocol.md` — the triage loop's first step was pure prose with nothing to check it against; now pins down what the idea is, what it's for, and what's already fixed, without turning into a form.
- "Shape of a Converged Output" section in `references/protocol.md` — a structural (not content) template for what a finished council pass looks like, so a session can't accidentally skip the verdict step and call itself done.

**Verified after edit:** rename left no orphaned "Savage" or "Adam Savage" outside historical changelog text; grammar around every renamed instance checked in context, not just grepped; evals.json still valid JSON; all cross-file references (Paired Check pairs, RELATIONSHIP_MAP contract targets) still resolve to the new name.

## 1.2.0 — Full persona depth pass

All six lenses expanded from four fields to seven, at verified parity (231–284 words each, seven fields each — checked programmatically, not eyeballed):

- **Good For** (existing)
- **Method** — how the lens actually works a problem, not just what it values
- **Signature Move** — one concrete technique drawn from the real historical approach, paraphrased rather than quoted, never costume dialect
- **Habitual Question** (existing)
- **Voice Notes** — how the lens should sound in output, as a direct anti-pattern guard against the existing "no costume-drama dialect" rule
- **Unchecked Failure Mode** (existing)
- **Paired Check** (existing, unchanged — the three pairs were not touched)
- **When This Lens Leads** — the idea-shape that should pull this lens forward first, giving the triage loop a faster way to pick a pair than reasoning it out from scratch each time

Cross-reference integrity re-verified after the edit: the Paired Check relationships, the protocol.md failure-condition example, and every "five/six" lens-count reference were re-checked and still hold. No fields were added to `protocol.md` or `RELATIONSHIP_MAP.md` — the expansion is contained to `personas.md`, since nothing downstream needed new hooks.

## 1.1.0 — Kaizen audit pass

Audit method: TABARC C1–C10 determinate invariants (adapted from `alchemy-hive/core/colony-core.md`, C1–C10 are web-specific in origin; only the file-level equivalents were applied — reachability of internal links, canonical single-purpose per file, named user problem per section, information-gain/counterfactual test, trust/version signals, purposeful internal linking).

**Fixed:**
- `SKILL.md` — "five-voice transcripts" / "Five distinct voices" corrected to six, matching the actual six-lens structure. Left every other "five" usage untouched where it was already correct (e.g. "the other five lenses" from a single lens's own point of view).
- `references/protocol.md` — replaced a stale failure-condition example ("Da Vinci and Franklin both nodding along") that no longer matched the formal Paired Check pairs, with an example that actually demonstrates the rule it's illustrating.
- `evals/evals.json` — eval #1 expected a Savage+Newton foreground pairing that isn't a defined Paired Check relationship and would have required the skill to violate its own triage doctrine to pass. Corrected to the Da Vinci ↔ Savage pair, which is what the eval's underlying scenario (has this been tried, does it survive contact with a grinder) actually needs.

**Added:**
- `metadata.version` field to `SKILL.md` frontmatter, and this file, so future audits can distinguish "checked and current" from "drifted since last check." Deliberately minimal — one version number at skill level, not per-file stamps, since nothing currently requires the reference files to version independently of the skill they belong to.

## 1.0.0 — Initial build

Six-lens merged-persona invention council (Da Vinci, Newton, Tesla, Fuller, Franklin, Adam Savage), spider-swarm research layer, keep/discard/refine triage loop, non-human cognition clause. Full bidirectional linking added between `SKILL.md`, `references/personas.md`, `references/protocol.md`, and between the three Paired Check persona relationships, formalised in `RELATIONSHIP_MAP.md`.
