> **Reference for `officina`.** Linked from `../SKILL.md` (§ The Spider-Swarm, § The Trickster, § The Return Pass, § Working Modes) — read this file for full council sessions and return there for the working-mode table. Cross-linked with `personas.md` (§ Paired Check fields, consumed directly by the Multi-lens critique step below). Full link map: `../RELATIONSHIP_MAP.md`. Defines the research procedure, the premise-check stage, the return-visit comparison stage, and the keep/discard/refine loop.

# The Spider-Swarm

## What it actually is

Not a metaphor to describe in the output. A functional instruction: before the council reasons about anything checkable (does this exist already, what's the current state of the material/method, has this failed before, what's the actual physics/cost/regulation), dispatch real web_search calls rather than reasoning from memory. Multiple narrow queries, not one broad one — each "spider" checks one specific thing (prior art, material properties, existing patents, current pricing, a named competitor product, a specific physical constraint) and reports back.

## Scaling

- **Quick reaction mode:** zero to one search, only if there's an obvious factual check (does this thing already exist under another name).
- **Full council session:** scale to the idea's complexity. A genuinely novel mechanical concept needs prior-art checks, material checks, and feasibility checks — that's easily five to ten searches before the council should say anything confident. Do not shortcut this because the idea "feels" original. Memory is exactly where confident wrongness about prior art lives.
- **Single-lens consult:** whatever that lens would actually need — Newton wants mechanism verification, Vagadesamaso wants "has this been built," Franklin wants "does something like this already exist for people to use."

## Folding results back in

Findings get absorbed into the reasoning inline, attributed plainly ("turns out something close to this already exists — a 2019 patent covers roughly this mechanism"), and they change the shape of the answer. They do not get appended as a separate "research findings" section bolted onto a pre-decided conclusion. If the swarm comes back with something that kills the idea, kill the idea. If it comes back with something that sharpens it, sharpen it before presenting anything to the user.

**If a search comes back empty, inconclusive, or the tool fails.** Say so plainly rather than reasoning as if the check never happened. "No prior art turned up in a search" is a real finding — it's weaker evidence than a confirmed check, and the output should carry that weaker confidence, not silently borrow the certainty of a search that actually succeeded. A claim stated with search-level confidence off the back of an empty search is a worse failure than the same claim stated as unverified.

Standard copyright and citation discipline applies throughout — paraphrase findings, do not reproduce source text.

# The Trickster

Every stage in the rest of this file interrogates *how* to build the thing the user asked for. None of them interrogate whether the user asked for the right thing. That's a real gap, not a stylistic choice — the six lenses, however well they're paired, all inherit the objective as given and refine within it. The Trickster is the one check in Officina that's allowed to reject the objective itself.

**What it does:** before the triage loop runs on the mechanism, ask whether the stated goal is the goal worth pursuing. Not "is this a good plan" — that's what the six lenses are for. The Trickster's question is one level up: "is this even the right game to be playing."

**How it works.** Three moves, in order:

1. **Name the load-bearing assumption.** State one assumption underneath the stated objective that, if false, makes the objective irrelevant — not a minor caveat, the actual foundation.
2. **Propose the alternative objective.** If that assumption is genuinely shaky, name a different goal that routes around the original problem entirely, rather than solving it better.
3. **Ask the refusal question, out loud:** "What game are we actually playing here, and should we be playing it at all?"

**Where this sits in the loop.** Runs once, before Capture, in a full council session — see Triage Loop step 0 below. Quick reaction mode skips it by default; a dropped idea that's clearly sound on its own premise doesn't need its foundations audited. If a quick reaction spots a stated goal that's visibly solving a symptom rather than a cause, say so in one line and offer to escalate to a full session rather than running the whole Trickster procedure inline.

**Who decides whether to adopt the reframe.** No seventh lens, no separate referee persona — the gestalt core that already converges the six-lens critique at the end of the loop is the same authority that judges the Trickster's reframe. If the premise genuinely doesn't hold, the rest of the loop runs on the Trickster's reframed objective instead of the original one, and the output says so plainly. If the premise holds, the Trickster's challenge gets logged as considered-and-rejected (one line, same discipline as a Discard verdict) and the loop proceeds on the original objective.

**If the reframe itself fails the critique.** Don't silently fall back to the original objective — that hides that a reframe was tried and buries the reasoning that killed it. Report both: the original objective, the reframe that was tried, and why the reframe specifically failed. The session ends in a Discard on the reframed objective, not a quiet reversion to the one the Trickster already found shaky. If the user wants the original objective critiqued on its own terms anyway — premise concerns noted but overridden — that's a fresh instruction, not something the loop should assume.

**Anti-pattern, specific to this stage:** the Trickster is not licence for reflexive contrarianism. A reframe has to survive on its own logic — if every session ends in "actually, wrong question," the Trickster has stopped being a check and started being a tic. Most premises are fine. The stage exists for the minority that aren't, not to manufacture drama on every drop-in.

# The Return Pass

Adapted from a production-baseline-control skill the user provided, built for tracking deployed systems, documents, and manufactured objects across releases over time. Most of it doesn't transfer — release gates, JSON schemas, monitoring cadences, decision ledgers, and severity-classified incident response are machinery for a completely different job, watching something that already shipped for deterioration. Officina doesn't ship anything and has no ongoing production object to monitor. It stayed out.

What's genuinely portable: the discipline of not re-litigating an idea from zero, and not quietly conflating "still broken," "newly broken," and "never actually tested" when someone comes back with a revised version of something Officina already gave a verdict on.

**When this runs.** Only when the user returns with a revised version of an idea Officina has already triaged earlier in the conversation. A brand-new idea skips this entirely and goes straight to the Trickster pass, or straight to Capture in quick reaction mode.

**What it does.** Treat the prior verdict — Keep, Discard, or Refine, and the reasoning behind it — as the baseline. Treat the new drop as the candidate. Before running the lenses again from scratch, sort what's changed into four buckets, not two:

- **Resolved** — the objection that drove the prior verdict is actually addressed. State what changed and why it now holds, don't just take the user's word that it's fixed.
- **Unresolved** — the same objection is still present, essentially unchanged. This is not a new finding. Don't present something already flagged once as freshly discovered.
- **Regression** — the fix for one objection introduced a new problem a different lens would catch. Name it as caused by the candidate, not as a pre-existing flaw that was somehow missed the first time around.
- **Drifted** — the candidate changed something the prior verdict never asked about. Flag it plainly rather than quietly re-scoping the session around whatever showed up in the revision.

**If the comparison itself is shaky** — the candidate changed so much context that the old verdict doesn't cleanly apply, or the original session's reasoning wasn't specific enough to check the revision against — say so rather than forcing a comparison that isn't real. A stated "can't cleanly compare this to the last pass, here's why" is more honest than a confident verdict resting on a comparison that doesn't hold.

**Then proceed as normal.** Trickster pass if warranted — a revision can still be solving the wrong problem, that doesn't reset just because the mechanism changed. Swarm pass on anything the candidate actually changed, not a full re-search of everything. Multi-lens critique focused on what's still open rather than re-running the full original critique. Converge and verify as usual.

**Anti-pattern, specific to this stage:** don't let "resolved" become the default assumption because the user clearly put in effort. Effort isn't evidence. Check the specific objection against the specific fix, the same way the original lens would have.

# The Triage Loop

Full council session shape, in order. If this is a return visit on an idea already triaged earlier in the conversation, run § The Return Pass first and let its output feed step 0 below rather than starting cold.

0. **Trickster pass.** Run the three-move premise check above. State the verdict — reframe adopted, or premise held — in one line before moving to Capture. This step is specific to full council sessions; see § The Trickster for when to skip it.
1. **Capture.** State the idea as dropped, plainly, without editorialising yet — using the reframed objective if the Trickster pass adopted one, the original if it didn't. Pin down three things before moving on — not as a form to make the user fill in, but as a check on whether the idea is actually captured or just heard: **what it is** (one sentence, mechanism or object, not the pitch), **what it's for** (the problem it's meant to solve, stated by the user or reasonably inferred), and **what's already fixed** (any constraint the user has stated — budget, material, scale, deadline — that the council isn't free to redesign around). If the third one is empty, that's fine; it means nothing's fixed yet, not that nothing was asked. If genuinely ambiguous what's being asked for, ask one sharp clarifying question rather than guessing — but don't stall on ambiguity that a reasonable default would resolve.
2. **Swarm pass.** Run the research needed per the scaling rules above.
3. **Multi-lens critique.** Foreground one or two of the three Paired Check pairs from `personas.md` (Da Vinci ↔ Vagadesamaso, Newton ↔ Tesla, Fuller ↔ Franklin) — never a lens without its paired check. Each lens contributes what it would actually catch, not a performance of catching it.
4. **Permutation pass.** Where the idea has real variants (different mechanism, different material, different scale, different audience), run the same critique across two or three permutations rather than defending the first version reflexively. This is where genuinely novel combinations tend to surface — a variant that no single lens would have proposed alone.
5. **Keep / Discard / Refine.** For the original idea and each permutation, land on one of three verdicts:
   - **Keep** — survives the critique as-is, ready to build or pursue.
   - **Discard** — a specific lens found a fatal problem; state which lens and why, plainly.
   - **Refine** — has real merit but needs a stated change before it survives; state the change.
6. **Converge.** Present the surviving idea (or the small set worth pursuing further), not a transcript of the whole internal argument, unless the user asked for transcript mode. State what got discarded and why in one line each — the discard reasoning is often more useful to the user than the surviving idea alone.
7. **Verification pass.** Before presenting anything, re-read the converged output against what the swarm actually found and what the paired-check lenses actually raised — this happens internally, it isn't shown to the user as a separate step. Two specific checks: does the stated verdict actually match its stated reason (a "keep" carrying a discard-shaped reason is a contradiction that slipped through, not a nuance worth keeping), and does the final output quietly contradict something the swarm found without explaining why. If either check fails, fix it before presenting. This step exists to catch drift between what was reasoned and what got written down — it is not a second opinion on the idea itself, that's what the paired lenses already did.

## Shape of a Converged Output

Not a script to fill in — the actual content varies completely by idea. What stays constant is the shape, so a session doesn't accidentally skip a step and call it done:

0. The Trickster verdict, one line (reframed, or premise held) — full council sessions only.
1. The idea, restated in one line (the Capture output).
2. What the swarm found, folded into prose — not a bullet list of search results.
3. The critique itself: which pair, what each side of the pair caught, stated as reasoning not as a costume performance.
4. Any permutations actually worth naming (not padding — omit this if none earned their place).
5. The verdict — keep, discard, or refine — with the reason in one line.

If a converged output is missing step 5, it isn't converged, it's a discussion.

## Failure Conditions

- Skipping the swarm pass because the idea seems self-evidently novel or self-evidently sound.
- Foregrounding a lens without its named Paired Check partner (e.g. running Tesla's leap without Newton, or Fuller's scale without Franklin) — the pairing exists to guarantee friction; skipping it produces two enthusiasms agreeing with each other, not a critique.
- Presenting "keep" on everything — if nothing gets discarded, the triage didn't happen, agreement did.
- Turning the permutation pass into padding — permutations exist to find better ideas, not to look thorough.
- Running the Trickster pass in quick reaction mode by default, turning a fast drop-in into a full audit nobody asked for.
- Reframing the objective on every full council session regardless of whether the premise actually holds — the Trickster is a check, not a reflex.
- Presenting Converge's first draft directly without the verification pass — this is where a verdict and its stated reason quietly stop matching each other, or where the final wording contradicts something the swarm found three steps earlier.
- Treating a returned idea as "probably fixed" because the user clearly put in effort, instead of checking the specific prior objection against the specific change — the Return Pass exists precisely to stop that assumption.
- Re-running the full original critique on a returned idea instead of focusing on what the Return Pass identified as still open.
