# Relationship Map — Officina

**Author:** TABARC-Code
**Author URL:** https://github.com/TABARC-Code/

Every relationship below is stated once as a contract with both directions filled in, not as a one-way "see also." Internal contracts (within this skill) plus two external sidecar contracts (to `perdita-mode` and `production-baseline-control`). Audited against the actual file content at time of writing — no relationship listed here that isn't reflected in the files themselves.

---

### Relationship Contract: SKILL.md → references/personas.md

**Source:** SKILL.md
**Target:** references/personas.md
**Relationship Direction:** SKILL.md names the six lenses at summary depth and routes the reader to personas.md for full definitions
**Reciprocal Direction:** personas.md opens with an explicit backlink to SKILL.md and routes the reader back to Working Modes once the lenses are understood
**Relationship Type:** summary/detail
**Relationship Strength:** critical
**Strength Reason:** SKILL.md cannot stay lean if it carries full persona depth; personas.md is meaningless without the working-mode context that tells the reader when to use it
**Direct or Indirect:** direct
**Chain Position:** first hop from entry point
**Behavioural Impact:** a full council session or single-lens consult must not proceed without reading personas.md; a quick reaction pass may skip it. **Sync note (added v1.3.0):** SKILL.md's "→ leads on:" cues in § The Six Lenses are condensed restatements of personas.md's "When This Lens Leads" field. If "When This Lens Leads" changes for any lens, the matching cue in SKILL.md must be updated in the same edit — this is the one piece of content duplicated across the two files, and it exists only to avoid forcing a full personas.md read for quick reaction mode.
**Affected Files:** `SKILL.md`, `references/personas.md`
**Audit Status:** verified

### Relationship Contract: SKILL.md → references/protocol.md

**Source:** SKILL.md
**Target:** references/protocol.md
**Relationship Direction:** SKILL.md names the spider-swarm, the Trickster premise-check, the Return Pass, and the triage loop at summary depth and routes the reader to protocol.md for procedure
**Reciprocal Direction:** protocol.md opens with an explicit backlink to SKILL.md and routes the reader back to the Working Modes table
**Relationship Type:** summary/detail
**Relationship Strength:** critical
**Strength Reason:** the triage loop is the actual mechanism of the skill, the Trickster is the one stage allowed to override the loop's own starting objective, and the Return Pass is what stops a revised idea being re-litigated from zero or rubber-stamped on effort alone; without any of the three, a meaningful part of what the skill claims to do doesn't actually happen
**Direct or Indirect:** direct
**Chain Position:** first hop from entry point, parallel to the personas.md link
**Behavioural Impact:** a full council session must not proceed without reading protocol.md; the Trickster pass specifically must not be skipped in full council sessions by default (added v1.5.0); the Return Pass specifically must run before the loop restarts on any idea that already received a verdict earlier in the conversation (added v1.7.0) — see Failure Conditions in both cases
**Affected Files:** `SKILL.md`, `references/protocol.md`
**Audit Status:** verified

### Relationship Contract: references/personas.md ↔ references/protocol.md

**Source:** references/personas.md
**Target:** references/protocol.md
**Relationship Direction:** personas.md defines the Paired Check field on each lens
**Reciprocal Direction:** protocol.md's Multi-lens critique step consumes the Paired Check field directly, by name, rather than re-deriving pairing logic
**Relationship Type:** data/consumer
**Relationship Strength:** critical
**Strength Reason:** if either file changes the pairing structure without the other, the triage loop breaks silently — protocol.md would reference pairs that no longer exist, or personas.md would define pairs the loop never uses
**Direct or Indirect:** direct
**Chain Position:** sidecar — these two files reference each other without routing back through SKILL.md first
**Behavioural Impact:** any change to which lenses are paired (in personas.md) requires a matching update to protocol.md § Multi-lens critique, and vice versa
**Affected Files:** `references/personas.md`, `references/protocol.md`
**Audit Status:** verified

### Relationship Contract: Da Vinci ↔ Vagadesamaso (persona pairing)

**Source:** Da Vinci (references/personas.md)
**Target:** Vagadesamaso (references/personas.md)
**Relationship Direction:** Vagadesamaso forces Da Vinci's endless-notebook tendency into a build/drop decision
**Reciprocal Direction:** Da Vinci's patience for observation-before-utility stops Vagadesamaso dismissing something real but not yet buildable
**Relationship Type:** paired check (leap/synthesis lens ↔ proof lens)
**Relationship Strength:** critical
**Strength Reason:** neither lens alone survives contact with a real invention problem — Da Vinci alone never ships, Vagadesamaso alone kills ideas too early
**Direct or Indirect:** direct
**Chain Position:** one of three symmetric pairs covering all six lenses
**Behavioural Impact:** the triage loop must not foreground Da Vinci without Vagadesamaso, or Vagadesamaso without Da Vinci, when this pair is in use
**Affected Files:** `references/personas.md`
**Audit Status:** verified

### Relationship Contract: Newton ↔ Tesla (persona pairing)

**Source:** Newton (references/personas.md)
**Target:** Tesla (references/personas.md)
**Relationship Direction:** Tesla supplies the leap Newton's rigor alone would never propose
**Reciprocal Direction:** Newton's rigor separates Tesla's brilliant leaps from the ungrounded ones
**Relationship Type:** paired check (rigor lens ↔ reach lens)
**Relationship Strength:** critical
**Strength Reason:** this is the pairing most likely to be skipped under time pressure, and the one where skipping it does the most damage — Tesla unchecked produces confident nonsense
**Direct or Indirect:** direct
**Chain Position:** one of three symmetric pairs covering all six lenses
**Behavioural Impact:** any idea reasoned through Tesla alone is provisional until Newton has checked the mechanism
**Affected Files:** `references/personas.md`
**Audit Status:** verified

### Relationship Contract: Fuller ↔ Franklin (persona pairing)

**Source:** Fuller (references/personas.md)
**Target:** Franklin (references/personas.md)
**Relationship Direction:** Franklin pulls Fuller's whole-systems scope back to what was actually asked for
**Reciprocal Direction:** Fuller keeps pulling the ceiling back up once Franklin has shipped the merely-useful small version
**Relationship Type:** paired check (scale lens ↔ pragmatism lens)
**Relationship Strength:** critical
**Strength Reason:** Fuller alone designs for a planet when the problem is a desk; Franklin alone settles for good-enough when one more iteration was available
**Direct or Indirect:** direct
**Chain Position:** one of three symmetric pairs covering all six lenses
**Behavioural Impact:** whole-systems reasoning (Fuller) must not be presented without a Franklin pass checking it against actual scope
**Affected Files:** `references/personas.md`
**Audit Status:** verified

---

### Relationship Contract: officina ↔ perdita-mode

**Source:** officina
**Target:** perdita-mode
**Relationship Direction:** officina borrows the research-swarm structural metaphor that perdita-mode established first
**Reciprocal Direction:** perdita-mode is not modified by officina's existence, but a session that starts in officina and turns out to be a people/incentive problem rather than an invention problem should be handed to perdita-mode rather than forced through the triage loop
**Relationship Type:** sidecar / domain boundary
**Relationship Strength:** moderate
**Strength Reason:** the two skills share no files and no direct dependency, but they share a metaphor closely enough that a user or a future audit could confuse them without an explicit boundary statement
**Direct or Indirect:** indirect
**Chain Position:** not part of officina's internal chain — external cross-reference only
**Reason for Relationship:** both skills use a distributed research-agent metaphor ("spiders" in officina, the equivalent scouting structure in perdita-mode) for the same underlying reason — live evidence beats confident memory — but apply it to different problem classes
**Behavioural Impact:** officina must redirect to perdita-mode when a dropped idea is actually a situational/relational problem, not an invention problem; perdita-mode is not required to redirect toward officina, since object/mechanism problems are less likely to arrive there first
**Source Update Requirement:** officina states this boundary in SKILL.md § Relationship to Other TABARC Skills
**Target Update Requirement:** none currently required of perdita-mode — this contract is recorded here for audit trail; if perdita-mode is revised and a reciprocal statement is added there, update this contract's Audit Status
**Affected Files:** `officina/SKILL.md`, `officina/RELATIONSHIP_MAP.md` (perdita-mode's own files unaffected)
**Audit Status:** verified on officina's side; not yet cross-verified inside perdita-mode's own files — flagging as out-of-scope rather than editing perdita-mode silently

---

### Relationship Contract: officina ↔ production-baseline-control

**Source:** officina
**Target:** production-baseline-control
**Relationship Direction:** Officina answers whether an idea should be built and in what form — a Keep/Discard/Refine verdict. Once a session ends in Keep and building actually starts, production-baseline-control picks up from there: establishes the first built/shipped form as a baseline and tracks it against drift.
**Reciprocal Direction:** production-baseline-control's Phase 15 (Review the production system) can surface recurring regressions that point back to a flaw in the original idea rather than its execution — at that point, handing back to Officina's Return Pass (which already has the original verdict on record) fits better than redesigning around the flaw purely within production control.
**Relationship Type:** sequential workflow handoff, not a file or code dependency
**Relationship Strength:** moderate
**Strength Reason:** genuinely useful when both are in play on the same project, but neither depends on the other to function — production-baseline-control is domain-neutral and works on objects that never went through Officina at all
**Direct or Indirect:** indirect
**Chain Position:** not part of officina's internal chain — external cross-reference only
**Reason for Relationship:** the two skills answer different questions at different points in a project's life; Officina operates before anything exists, production-baseline-control once something does
**Behavioural Impact:** Officina should mention production-baseline-control when a session ends in Keep and the user signals they're about to actually build or ship the result
**Source Update Requirement:** officina states this in SKILL.md § Relationship to Other TABARC Skills
**Target Update Requirement:** production-baseline-control carries the matching contract in its own `RELATIONSHIP_MAP.md`, added the same day as this entry — both sides verified together, not one flagged as pending like the perdita-mode entry above
**Affected Files:** `officina/SKILL.md`, `officina/RELATIONSHIP_MAP.md`, `production-baseline-control/SKILL.md`, `production-baseline-control/RELATIONSHIP_MAP.md`
**Audit Status:** verified on both sides

---

## Audit Summary

- 3 internal file-level contracts (SKILL.md ↔ personas.md, SKILL.md ↔ protocol.md, personas.md ↔ protocol.md) — all bidirectional, all verified against current file content.
- 3 persona-pairing contracts, covering all six lenses with no lens left unpaired — all bidirectional, all verified.
- 2 external sidecar contracts: `perdita-mode` (direction from officina verified; reciprocal statement inside perdita-mode's own files not made, flagged rather than silently added, perdita-mode out of scope for this build) and `production-baseline-control` (verified on both sides, since that skill was built in the same session as this contract).
